(function() {
    
    var app = angular.module('app', ['ui.router']);

})();