(function() {
	 var app = angular.module('app');

	  app
        .constant('config', {
            'URL_SERVER': 'http://localhost:5000'
        });
})();